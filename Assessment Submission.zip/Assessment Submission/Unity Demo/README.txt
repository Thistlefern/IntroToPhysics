For this Unity physics simulation, open the EXE file within the same folder as this README file.

This should open the PlaygroundSim scene, which is where my assessment piece is, but you're welcome to
check out the other scenes to see the nonsense I built while trying to learn physics!

Within the sim, there is an option to check the controls, but I'll list them here as well:
   - Mouse: move cursor to find objects to interact with, and click to do so
   - WASD: move your child around the scene
   - Space: help your child jump

The other scenes also implement simple WASD/Space player controllers as well.