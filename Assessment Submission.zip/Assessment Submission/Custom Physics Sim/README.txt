To run this simulation, open the Release folder above, and run the exe file found within.

The simulation lists your controls, but I'll list them here as well:
   - Left click to summon a dynamic circle
   - Right click to summon a static circle (EDIT: I bulit before adjusting the text to say static circle
					    here, and didn't feel the need to rebuild to fix that error)
   - Middle click to turn gravity on and off
   - Use up/down arrows to adjust the pull of gravity