﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RagdollPossess : MonoBehaviour
{
    private void FixedUpdate()
    {
        
    }
}
